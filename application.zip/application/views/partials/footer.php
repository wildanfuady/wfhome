<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        Build with <i class="fa fa-heart"></i> from Bogor
    </div>
    <strong>Copyright &copy; <?= date('Y') ?> <a href="#">PT. Bumi Tirta Graha Cemerlang</a></strong> | All rights reserved.
</footer>