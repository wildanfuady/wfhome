<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman 404 Page Not Found</title>
    <style>
        body {
            font-family: Consolas, Monaco, Courier New, Courier, monospace;
        }
    </style>
</head>
<body>
    <div style="padding-top: 10%">
    <center>
        <img src="<?= base_url('assets/img/404_page_not_found.png') ?>" alt="Halaman 404 Page Not Found" width="50%">
        <h1>NOT FOUND</h1>
        <a href="<?= base_url('/') ?>">Back To Home</a>
    </center>
    </div>
</body>
</html>